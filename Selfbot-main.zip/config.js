module.exports = {
    prefix: '.',
    ltc: 'LYhS5HGDowKi1Z7GzqwuJubmYy5MFJqmVN'
}